# Paper-to-code traceability

Source locators refer to the supplied PDF, not a recovered prototype. Status uses
S=specified, A=ambiguous/provisional, I=implemented, T=executed validation,
E=externally blocked. Multiple statuses are intentional: tested reconstruction
choices do not become recovered specifications. See FINAL_REPORT.md for latest runs.

| Requirement | Paper locator | Module / public interface | Validation / evidence | Status |
|---|---|---|---|---|
| Single logical index and four states | §3.1, Fig.1 | index.Index, storage.Store, core.Graph | test_rotation_claim_fencing_and_restart | S,I,T |
| C++17 interval and graph kernel | §4 | cpp/core.cpp, Graph | portable Windows build, C++ oracle tests | S,I,T |
| RocksDB manifest integrated publication | §3.6, §4 | Graph.publish; Store.transaction/native | hard-exit tests; callback mirror protocol | S,I,T; language split is choice |
| Durable region/version/state per node | §3.1 | Store.node/nodes | reopen after publication/crash | S,I,T; JSON instead of packed metadata |
| Read-only corpus | §3.1, §5.6 scope | Index exposes no insert/delete during upgrade | configure rejects chaining; immutable raw validation | S,I |
| Genuine layered graph | §4 | Graph.build/append/search | independent 500-vector exact oracle; upper layers exist | S,I,T |
| M32, efC200, alpha1.2; serving ef96 | §4; Table5 | Graph constructor; provisional.json | configured; smoke uses explicit smaller values | S,I; paper-scale E |
| HNSW levels/entry point/locks | §4 omissions | seeded geometric levels; highest entry; shared mutex/service lock | graph/reverse tests, ownership races | A,I,T |
| Alpha robust neighbor pruning | §4, §3.5 | Graph.prune/build/repair | degree bound, independent recall and consistency checks | S,I,T |
| Independent exhaustive oracle | §5.1 | evaluation.Oracle | certificate enumeration and graph recall checks | S,I,T |
| Old-space coarse regions R256 | §3.2, §5.1 | calibration.partition | real smoke KMeans; configurable R sweep | S,I,T; R256 experiment E |
| 400 stratified pairs; 200+200 | §5.1 | sample_regions/regional | explicit identity lists, real raw encoder | S,I,T; smoke downsized |
| Empty/small regions | §3.2 support premise | sample_regions(...region_count), regional | test_empty_regions_and_small_support | A,I,T |
| Equal-width Procrustes | §3.2 | math.fit_bridge | orthogonality and known-map independent oracle | S,I,T |
| Rank64 affine bridge | §3.2 | math.fit_bridge(rank,ridge) | numerical rank and independently optimized objective | S,A,I,T |
| Exact objective/regularization/preprocessing | omitted §3.2 | centered reduced-rank ridge; normalization | equation in math.py; independent optimizer | A,I,T; originals unknown |
| Actual successor embeddings from raw | §3.2, §4 | Encoder.encode; Index.raw | MiniLM→MPNet public AG News CPU run | S,I,T |
| Regional s=abs(dhat-dstar) | §3.2 | calibrate_region | numeric checks and offline independent coverage | S,I,T |
| ceil((1-alpha)(m+1)) statistic | §3.2 | math.quantile | ranks across m=0..59 and four alphas | S,I,T |
| Unsupported rank => infinity | §3.2 mathematical implication | quantile/regional/query_epoch | empty and small support tests | S,I,T |
| epsilon_r, epsilon_cert, gamma_r distinct | §§3.2-3.5 | regional/query_epoch/core intervals/repair | three separately stored fields; certificate oracle | S,I,T |
| Separate identity splits | §5.1, Table3 | datasets.prepare; sample_regions | hashed split manifests; overlap rejection | S,I,T |
| Offline held-out size | literal placeholder §5.1 | offline_per_region required config | independently encoded offline items | A,I,T; historical setting E |
| dbar definition and diagnostic tau0.5 | placeholder §3.2; §5.6 | calibration.diagnostic | measured real smoke width, no hardcoded target | S,A,I,T |
| Query pool/m_q/epoch threshold | placeholders §5.1 | query_epoch/epoch_due, configs | 20-query smoke, interrupted replay restart | A,I,T; originals E |
| Freeze graph/manifest while replaying | §3.2, Prop.2 | Index.frozen; query_epoch | no early publication, service marker, restart test | S,I,T |
| Replay maximum over actual C | §3.2, Prop.2 | Graph.search; query_epoch | durable per-query visited lists/scores | S,I,T |
| Retain exact embeddings until scoring ends | §3.2 | Index.retain/publish_retained | early publication rejected, cache reused across restart | S,I,T |
| Calibration replay resolution disabled | omission around Alg.1 | query_epoch frozen Graph | marker blocks claims, repair and publication | A,I,T |
| Successor-only query inference | Alg.1 line1, §5.1 | Encoder.encode(role=query), RPC Query | P1 smoke; E5/CLIP role-aware code | S,I,T for P1; other pairs E |
| Native/query normalized; bridge not | §5.1 | math.normalize; bridges/core | norm tests, actual encoder output | S,I,T |
| Streaming dimension-changing rotation | §3.2 dimension paragraph | Index.rotate_one/rotate | 4→6 hard-exit frontier recovery; real384→768 run | S,I,T |
| Legacy candidates bridge on demand | §3.1, Fig.1 | Graph.vector_unlocked | graph vectors before/after rotation match | S,I,T |
| No double transformation/publication races | §3.6, Alg.1 line5 | state gates + Graph.publish | interrupted segments, stale fences | S,I,T |
| One-way noninvertible rotation | §3.2 dimension paragraph | Index.configure; reclaimed old segments | documented rollback requirements | S,I |
| Storage includes all live index files | §3.2; Table4 | Store.measure, experiment economics | actual raw components/temporary vectors/DB files counted | S,I,T; strict compaction peak bound E |
| Candidate set definition | Alg.1 line2 ambiguity | Graph.search | all scored nodes across layers, raw candidate lists | A,I,T |
| Boundary membership/order | Alg.1 lines3-4 | core.ambiguity | closed overlap and deterministic order test | A,I,T |
| Default rho4 and async/sync | Alg.1 lines4-7 | Index.search | async leaves intervals; sync waits/reranks C | S,I,T |
| Atomic claims, leases and wait/retry | Alg.1 line5, §3.6 | Store.claim/acquire; Index.search | competing threads, lease expiry, stale publication | S,I,T |
| Duplicate delivery binds one physical worker | §3.3 embed-once claim; user clarification | Store.acquire; Local/CloudWorker | duplicate independent workers call encoder once | S,I,T |
| Preemption can recompute | §3.6 | fencing/visibility/recovery | hard exits and expired owner tests | S,I,T; real AWS preemption E |
| Exact native endpoints; resolving intervals | Alg.1 line8 | core.interval/certificate | exhaustive certificate oracle, async tests | S,I,T |
| m strict clears every nonreturned lower; m/k | Alg.1 lines8-9, Prop.2 | core.certificate | random exhaustive small-set rankings, ties, empty C | S,I,T |
| Candidate count, level, epoch, applicability | Prop.2 scope; §3.3 | Index.search metadata | snapshot-valid before seed, invalid after publication | S,I,T |
| No full-corpus or evolving guarantee | §3.3 continuation, §5.6 | flags; Oracle.assess | full and examined recall/soundness both recorded | S,I,T |
| Heat * epsilon_r * in-degree | §3.4 | Scheduler.schedule | measured scored heat, maintained reverse degree | S,I,T |
| Region batching and dollar bucket | §3.4 | Scheduler, Budget | reservation/reconciliation/debt/pause tests | S,I,T |
| Calibration/query/boundary/retry accounting | Table4 caption, §5.4 | Budget.account, worker telemetry | raw per-batch work ledger, real CPU measurement | S,I,T; GPU busy hardware E |
| Expedited work with explicit price | §5.4 burst | schedule(origin=expedited), Budget.price_for | interface and category-price tests | S,A,I |
| Pause/resume and reserve/send recovery | §3.4, §3.6 | Budget.pause; Scheduler.recover_pending | reserve+partial claim restart, convergence | S,I,T |
| Separate seed/query/scheduled observability | §3.2, Table2 caption | metadata origins, search/status | per-node origin and per-query fractions | S,I,T |
| f denominator | Table2 literal alternatives | config.fraction_denominator | whole default choice recorded; both formulas | A,I,T for whole; original E |
| Full convergence and retire | §§3.1,3.4 | Index.retire/search | all native, compact, reopen; test_retirement forbids interval/heat work; separate real replay | S,I,T |
| Neighbor/reverse/two-hop auditor pool | §3.5 | Graph.repair | reverse consistency, graph recall before/after | S,I,T |
| gamma for edge uncertainty; native zero | §3.5 | Graph.residual/prune | separate gamma path; native-only tests | S,I,T |
| Queue ambiguous decisions and native pivots | §3.5 | ambiguous_edges/repair_queue | durable queue in native publication | S,I,T |
| No pool re-embedding/global repair claim | §3.5, §5.6 | Graph.repair has no encoder interface | encoder call count unchanged during native repair | S,I,T |
| Data-first sync, manifest sync, reclaim | §3.6 | Graph.publish; Store.write_array/native/reclaim | six hard-exit barriers, RocksDB recovery | S,I,T |
| Atomic memory vs durable state | §3.6, §4 | C++ publish callback under service lock | failure before/after WAL publication | S,I,T |
| RocksDB WAL/S3 snapshots/raw versioning | §4 | Store.snapshot; S3Raw | local checkpoint reopen + SDK stubs | S,I,T locally; real S3 E |
| Actual SQS and direct aggregated gRPC | §4 | SQSQueue, Batcher/RpcServer/RpcClient | real loopback gRPC + SQS SDK wire stubs | S,I,T locally; AWS E |
| P1-P4 encoders, revisions, prefixes/limits | Table1, §5.1 | embeddings.MODEL_SPECS/PAIRS, model lock | pinned P1 actual inference; GloVe hash/CLIP/E5 code | S,I,T P1; P2-P4 runs E |
| Exact dataset release/selection | Table1 placeholders | hashed input preparation / NQ+TSV imports | actual AG News smoke manifest | A,I,T smoke; original corpora E |
| Rare entity identification/frequency | §5.6 literal placeholder | datasets.rare_entities; supplied annotation script | explicit document-frequency choice, no inferred NER | A,I; historical experiment E |
| NoAdapt projection vs truncation | §5.1 continuation | baselines.noadapt_maps | choose by offline queries, actual replay | S,A,I,T |
| Best global adapter candidate families | §5.1 continuation | global_adapter | Procrustes/affine/MLP; validation MSE selection | S,A,I,T |
| Real DualIndex backfill + cutover | §5.1 | DualIndex.backfill + synced alias | actual encoder, incrementally built second graph | S,I,T locally |
| FullReembed encoder/graph work | §5.1 | full_reembed | independent new inference and graph construction | S,I,T locally |
| Seed/no resolution/async/native repair variants | Table2, §5.6 | experiment.run | all actual raw query logs | S,I,T locally |
| Oracle isolation | §5.1; user requirement | evaluation.Oracle outside serving roots | serving encodes raw; ground truth only assesses results | S,I,T |
| Five seeded Zipf(1.0) replays | §5.1 | zipf_replay, experiment configs | five seeds, repeating actual identities | S,I,T |
| Tables2-5 from raw outputs | §8, table captions | evaluation.tables | CSV regenerated from query/coverage/economics JSON | S,I,T locally; historical results E |
| Latency/QPS/core protocol | Table5, §5.6 scope | replay index vs end-to-end timers | single-client measured rate, not saturated paper test | S,A,I,T smoke; paper protocol E |
| AWS r6i/g5/c6i/gp3 scale | §5.1 | cloud backend + deploy instructions | no credentials; no GPU on this host | S,I,E |
| Chaining outside evaluated scope | §3.6, §5.6 | Index.configure rejects second upgrade | test_legacy_candidate_claim_does_not_rotate_corpus; documented direct re-embed path | S,I,T |
| Provenance/clean build/CI | §8 placeholders; user deliverables | README, PROVENANCE, CI, source hashes | Windows native build, local tests, real experiment | I,T; hosted CI E |
| GitHub publication and installed package | user release request | setup.py, settings.load, MANIFEST.in | Windows wheel built and loaded outside checkout; bundled configs/native search | I,T; hosted CI unrun |
| Cloud retained reuse and direct cost accounting | §§3.2,3.6,4 | Acquire, RpcClient.encode_measured, RPC Query | real loopback protocol tests; CPU actual MPNet RPC operation check | I,T locally; live AWS E |
| Completion reconciliation after interruption | §§3.4,3.6 | RPC Work retry, Budget.reconcile | test_completion_event_recovers_reconciliation_gap | I,T |
| Remote image byte transport | §4 P3 worker operations | image_payload; Encoder.encode CLIP byte input | checksum roundtrip tested; CLIP inference remains unrun | I,T transport; P3 inference E |
| Immutable smoke dataset download | user reproducibility requirement | smoke_data.main | pinned Parquet SHA and prepared hashes match recorded smoke | I,T |

The provisional controls do not recover author intent. No test compares measured
recall, timing, cost or storage to the paper's table values as an expected output.
