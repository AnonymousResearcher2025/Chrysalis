# Executed reconstruction report

This is newly authored, executable research software reconstructed from the supplied
seven-page Chrysalis paper. It is not the inaccessible original implementation and
has not reproduced its historical results. The source, tests, configurations, raw
inputs, raw measurements and exact executed-source snapshot are delivered together.
No table values are expected outputs or calibration targets.

## Implemented system

The C++17 kernel implements a genuine seeded, layered HNSW-style graph, beam
traversal and alpha robust pruning; serving never calls the exhaustive oracle.
It owns state-aware distances, legacy on-demand bridging, regional ambiguity,
strict examined-set certificates, native publication mirrors and local edge repair.
The Python host implements regional fitting/calibration, frozen replay epochs,
streaming dimension changes, durable claims/fencing, retained embedding reuse,
utility scheduling, dollar reservations/reconciliation, recovery and retirement.
RocksDB supplies the authoritative manifest and synced WAL through rocksdict.
Actual PyTorch successor inference drives local workers and aggregated gRPC.
Cloud adapters call the actual SQS/S3 SDK and use the same host publication protocol.
Cloud workers acquire physical ownership before inference; expired leases can still
cause recomputation across crashes. Exactly-once physical encoding is not claimed.

Three separately stored quantities have different uses: epsilon_r for query-item
resolution, epsilon_cert for query-max-error certificates, and gamma_r for the
heuristic item-item auditor. Unsupported finite-sample conformal ranks yield
infinity. Native/query vectors are unit-normalized; bridged vectors are not.
Frozen calibration retains exact embeddings and completes durable scoring before
any seed publication. Publications/repairs invalidate snapshot applicability;
evolving bounds remain diagnostic empirical measurements.

FullReembed performs fresh encoder work and graph construction. DualIndex performs
real incremental second-index backfill followed by a synced cutover marker.
NoAdapt compares truncation and seeded projection using offline validation.
GlobalAdapter fits padded Procrustes, reduced-rank affine and a PyTorch residual
MLP using the same regional paired budget, selecting paired held-out MSE.
No-resolution, async, sync, scheduled migration and native repair ablations all
execute actual operations. Independent float64 exact new-space rankings assess
full-corpus and examined-set recall separately; oracle vectors stay outside serving
roots and are never given to migration, calibration, resolution or scheduling.

The current retired serving path removes interval/certificate/resolution/heat work.
All nodes must be native before retirement. Native overlays compact into segments;
maps, regional residuals and active certificate epochs are retired. Historical
work/ownership ledgers remain available. Chained upgrades are rejected.

## Executed checks

The portable Zig C++17 build completed on Windows 11 with Python 3.12.2. The current
suite passed **28 tests** (`docs/tests.xml`, 30.61 seconds). Tests include independent
orthogonal/affine fitting checks and rank/objective verification; conformal ranks
and insufficient support; exhaustive small-candidate certificate checks and tie
handling; layered graph recall/reverse edges; frozen calibration and interrupted
replay without premature publication; async/sync resolution; competing claims;
lease expiry; stale publication; duplicate physical worker ownership; budget debt,
duplicate reconciliation and reserve/claim/send recovery; dimension-changing
rotation; native-only repair with zero encoder calls; convergence, restart,
retirement and rejection of a subsequent chained upgrade.

Hard-exit subprocess tests exercised data sync, manifest sync and reclamation
barriers for rotation and native publication, using actual RocksDB WAL recovery.
Loopback gRPC transport and batching ran. SQS/S3 API contracts were checked with
SDK stubs and local checkpoint recovery, not a live AWS deployment. No power-cut,
multi-host failover or real spot-preemption experiment is claimed. The Linux CI
workflow is configured but has not run on a hosted runner here.

An isolated extraction of the source archive compiled a new extension and passed
all 28 tests again in 30.78 seconds (`docs/clean-check-tests.xml`); the CLI loaded.
This used the existing recorded Python environment and shared compiler cache,
not a new dependency installation. No prebuilt extension was extracted or reused.

## Real-input experiment

`runs/smoke-final` contains the primary successful run. It uses actual public
AG News raw texts and immutable MiniLM/MPNet checkpoints, on CPU with four Torch
threads. This is a smoke experiment, not Wiki/NQ, MARCO or LAION reproduction.

| Setting | Executed value |
|---|---|
| Dataset | fancyzhx/ag_news, revision eb185aade064a813bc0b7f42de02595523103ca4 |
| Corpus | first 160 train texts |
| Query inputs | following 140 texts, shuffled disjoint role pools |
| Pools used | residual 20; epoch replay 20; offline 20; evaluation 32 |
| Model pair | P1: MiniLM 384 dimensions to MPNet 768 dimensions |
| Region/sample sizes | R=1; 8 fitting, 20 residual, 12 offline items |
| Graph | M=4, efConstruction=32, efSearch=4, alpha_prune=1.2 |
| Resolution | rho=4; async and synchronous variants |
| Replays | five seeds, Zipf(1.0), 20 requests per variant per seed |
| Money | explicit CPU price $0/hour; capacity $1, refill $1/hour |
| Diagnostic | relative width 0.3300, below configured tau=0.5; no override |
| Certificate | epsilon_cert=0.4485507656, alpha_q=0.05, replay support 20 |
| Initial native seed | 77/160 = 48.125%, including retained replay candidates |

Corpus SHA256 is `4a77152486ed5717dda78929558356bdded47afdb79e4da0344afb8e751d2fbe`;
query-pool SHA256 is `a2c329fbab0146b9e9f887f4469126ae2bc6ab256e4e5da180abc14a3bf50be2`.
Checkpoint revisions, token limits, normalization and role-specific preprocessing
are recorded in `configuration.json` and `configs/models.lock.json`.
Skinny beams preserve an unresolved remainder in the tiny corpus; the resulting
ANN recall does not represent the paper's M32/ef96 serving experiment.

There are 1,000 primary query records across ten configurations, plus 100 real
queries for a separately recorded current retired-fast-path evaluation. Each row
records actual C, returned IDs, recall, timers, bounds where applicable, epoch and
snapshot flags, native fractions and resolution requests. CSV Tables 2-5 are
generated from these raw rows and recorded coverage/economics, not from the PDF.

| Configuration | Full-corpus recall@10 | Examined recall@10 | Mean bound | Index p50 ms | Observed sequential QPS |
|---|---:|---:|---:|---:|---:|
| NoAdapt | 0.059 | 0.512 | — | 0.245 | 6.50 |
| GlobalAdapter | 0.304 | 0.648 | — | 0.256 | 6.65 |
| FullReembed | 0.330 | 1.000 | — | 0.161 | 6.79 |
| DualIndex | 0.330 | 1.000 | — | 0.164 | 6.77 |
| SeedNoResolution | 0.234 | 0.718 | 0.496 | 1.692 | 7.06 |
| SeedAsync | 0.252 | 0.856 | 0.750 | 1.950 | 2.76 |
| SeedSync | 0.260 | 0.914 | 0.856 | 2.005 | 2.94 |
| Scheduled25 | 0.291 | 1.000 | 0.999 | 1.694 | 6.24 |
| NativeNoRepair | 0.291 | 1.000 | 1.000 | 1.678 | 7.19 |
| NativeRepair, primary source | 0.338 | 1.000 | — | 1.580 | 7.45 |
| NativeRetiredFastPath, current source | 0.338 | 1.000 | — | 0.285 | 6.81 |

The global adapter selected low-rank affine using 28 regional pairs and explicit
held-out MSE. The smoke MLP used 20 optimization steps, a downsized reconstruction
choice. Offline regional coverage was 12/12; that tiny sample cannot establish
population coverage. Resolution was requested on 44% of initial async/sync queries.
Async index p99 was 17.033 ms; sync p99 was 679.926 ms on CPU. Observed QPS includes
query encoding and intervening local queue drains. Reciprocal mean index latency
is separately labeled a service rate; neither metric is saturated load-test QPS.
The local async benchmark drains work after each returned request, so it does not
establish concurrent production scheduling/latency behavior.

All empirical examined-set soundness rates were 1.0 for bound-bearing variants.
Those queries had zero snapshot-applicable counts after seed publication. These
are evolving-index observations, not a fresh proof of coverage. For example,
Scheduled25's full-corpus soundness was only 0.01 despite examined soundness 1.0.
NativeNoRepair's exact candidate bound was 1.0 while full-corpus recall was 0.291.
The measured distinction illustrates why examined-set certification cannot certify
global ANN recall or routing quality.

All five async replicas converged to 100% native, followed by repair and retirement.
Repair rewrote 836 adjacency endpoints per seed without any pool encoder calls.
Before retirement, 25–32 items per seed had query origin and 51–58 scheduled origin;
seed, query and scheduled counts remain separate. Migration encoder batch time,
including calibration, was 26.75–27.21 seconds per replica; query encoding was
12.38–14.30 seconds separately. GPU busy hours are zero because no GPU was used.
FullReembed and DualIndex measured 20.14 and 18.85 encoder seconds respectively;
this small CPU run provides no demonstrated Chrysalis speed or cost advantage.

The primary experiment elapsed 359.95 seconds excluding checkpoint loading and the
later retired evaluation. A configured 20-query sliding mean first reached bound
0.95 during Scheduled25 at 39.82–43.00 seconds, measured from calibration start
plus each replica's elapsed workflow. This window/time definition is a documented
reconstruction choice, not a recovered historical measurement protocol.

Sampled peak live serving storage was 7,806,217 bytes per Chrysalis replica;
final measured storage was 900,729–914,286 bytes. Raw items, temporary vectors,
maps, residuals, RocksDB manifests/WAL/SST and queues are counted. The comparison
FullReembed/DualIndex vector+graph files occupied 495,697/746,208 bytes, with a
different metadata basis; these are not fair normalized footprint ratios. No
1.06x claim is supported. Model checkpoints, oracle exports, source and input
datasets are outside serving-root storage. Between-operation file sampling can
miss compaction spikes and does not measure RAM; a strict resource bound needs
continuous filesystem/RSS instrumentation and consistent baseline metadata.

## Source/evidence integrity

`source-hashes.json` records source at entry to the primary experiment. All 37
recorded files were captured byte-for-byte into `executed-sources` before later
edits. The current retired fast path was tested and measured separately, with
`retired-source-hashes.json`. Throughput postprocessing has separate source hashes.
`durable-evidence` exports authoritative node origins, budgets, work logs and replay
epochs for inspection. Per-seed snapshots/indexes can be reopened with the current
code. Recorded economics are the measurements at execution boundaries; reopening
RocksDB can change its physical file sizes and must not overwrite those numbers.
Earlier successful engineering runs and a failed stale-extension smoke attempt
are not relabeled as the primary run or historical evidence.

## Unresolved choices, deviations and blockers

Grouped clarification requests were sent after inspecting the paper/workspace;
no original configuration answers have been supplied. Provisional settings remain
explicit: dbar as mean exact residual-sample distance; 512 replay queries, 5% epoch
trigger and 200 offline items/region in the paper-sized template; whole-corpus f
denominator; centered rank-64 ridge objective with lambda=1e-6; closed boundary
overlap ordered by intersection length then ID; replay resolution disabled; and
seeded geometric graph layers with serialized host publication. Smoke values
override these transparently. The traceability matrix distinguishes
specified, ambiguous, implemented, executed-tested and externally blocked rows.

The architecture uses native RocksDB through Python rather than linking RocksDB
inside the C++ kernel; data-first publication crosses a synchronous callback.
Durable JSON metadata/dense maps, NumPy segments and a coarse service lock trade
throughput/storage for auditability. They are genuine implementations, but do not
recover the original packed metadata, lock layout or performance. Finite rank,
raw-item immutability, small/empty-region support and unsupported chaining are
handled explicitly; noninvertible rotation is one-way after old-data reclamation.

Exact Wikipedia/NQ and LAION releases, splits, passage/caption construction,
selection failures and rare-entity identification/frequency rules remain unknown.
Dataset preparation requires explicit hashed inputs. Rare-entity analysis accepts
versioned annotations and documents its provisional document-frequency definition.
No original rare-entity result has been reproduced. P2/P3/P4 inference paths and
revision/preprocessing configurations are implemented, but no real run for those
pairs was executed; GloVe requires its explicitly hashed local asset and P3 requires
retained image bytes. R256, 200+200 regional pairs, region/alpha sweeps and the
multi-million-item experiments remain unrun. The input/hardware requirements for
those runs are provided, but large-scale runtime/memory behavior is unverified.

This host has no available CUDA GPU and no configured AWS credentials. Therefore
live SQS/S3, A10G utilization, cloud billing, r6i/g5/c6i/gp3 serving, real worker
preemption and paper-scale throughput are externally blocked. The cloud code is
not represented as a passed cloud experiment. The original guarantee scope also
requires exchangeability on a frozen routing snapshot; neither recalibration alone
nor native publication/heuristic repair establishes coverage on changed routing.

## Independent execution

Follow `README.md` on a local filesystem, build the C++ extension, run tests, then
run the real smoke or prepare explicit corpus/query manifests for a larger run.
The delivered ZIP includes source, all primary raw query measurements, seed/final
indexes, durable exports and AG News raw manifests. It excludes downloadable model
weights, Python environments and compiler caches. Tables regenerate offline with
`python -m chrysalis.cli tables runs/smoke-final`; new migrations use
`python -m chrysalis.cli experiment ...` and produce a new output directory.
