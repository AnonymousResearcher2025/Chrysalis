# Architecture and operational contract

The C++17 Graph owns layered adjacency, reverse edges, vector/state/region/fence
mirrors, legacy on-demand bridges, robust pruning, beam traversal, ambiguity,
intervals and certificates. Index is the Python single-host service. The manifest
adapter is RocksDB through the native rocksdict wheel, rather than a second C++
RocksDB linkage. Graph.publish holds the core publication lock, invokes a data-first
durable manifest callback, updates its mirrors, then invokes reclamation. This is
an explicit reconstruction language-boundary choice; it changes overhead.

RocksDB owns the authoritative manifest/WAL. State strings and JSON records favor
inspection over the paper's packed two-bit/two-byte metadata. Each vector lives
in a synced NumPy segment or native overlay; maps, residual arrays, replay scores,
epochs and queues are persisted in RocksDB. Segment rotation uses region-grouped
GEMMs, publishes one metadata WriteBatch with WAL sync, and reclaims unreferenced
segments before the next. Legacy candidates are transformed in C++ only while
their state is legacy. Bridged/resolving/native vectors are never transformed twice.
Native overlays are compacted at retirement. Maps are dense in this reconstruction;
JSON and overlays can dominate small-index storage. 1.06x is not an implemented
resource bound; storage is measured, not forced to match the paper.

The service RLock serializes manifest transactions with C++ mirror changes and
provides a consistent per-query routing snapshot. C++ uses a shared mutex for
graph reads and exclusive publication/repair. This coarse single-host concurrency
policy is a reconstruction choice, not the lost prototype's lock implementation.
Cloud workers never open RocksDB; they claim/publish through host gRPC. One durable
lease/fence identifies each active owner. Duplicate delivery does not duplicate
publication. Lease expiry can repeat physical inference, and there is no claim
of exactly-once physical encoding across process/worker failures.

## Candidate set and numerical conventions

C contains every distinct node for which the actual layered traversal computes a
distance, including upper-layer entry points and scored neighbors rejected from
the retained beam. S is the smallest k of C by (estimated distance, ID). Navigation
uses un-clamped estimates (the paper's midpoint convention), not the midpoint of
a lower-clamped interval. Sync resolution preserves C and reranks it after successful
native publication; it does not secretly do another graph search. Native endpoints
are exact. Resolving endpoints retain their published bridged vector. Ambiguity
uses closed intersection with the kth estimated result's regional interval, ordered
by descending intersection length, then ascending ID. These are provisional choices.
Strict certificate comparisons use float64 distance accumulation and ordinary IEEE
comparisons. Infinite radii are conservative; NaN vectors/radii are rejected.
Distance ties break by ID in ranks and never clear a strict competing endpoint.
Empty competitors are vacuous. With fewer than k candidates the divisor stays k.

## Calibration

Old-space seeded k-means assigns uint16 regions. Region identity splits are shuffled
without replacement. Small regions proportionally reduce fit/residual/offline counts;
fewer than two fit samples requires explicit repartition or FullReembed. Empty
regions and unsupported conformal ranks never receive manufactured finite radii.
Equal dimensions fit uncentered orthogonal Procrustes; unequal dimensions solve
centered, reduced-rank ridge regression, rank at most 64. See math.fit_bridge for
the objective and thin-SVD solution. Epsilon_r uses query-item distance errors;
gamma_r uses vector norm residuals. Dbar is provisionally the mean exact distance
from the residual query-item sample; a zero reference means infinite relative width.

Query calibration holds a service lock and copies graph/vector routing into a
frozen Graph. Resolution and repair are disabled while scoring. Exact embeddings
are retained separately and reused. The durable epoch-scoring marker survives a
crash and blocks serving/publication until `epoch` restarts the entire replay with
retained outputs. The epoch commits scores/radius/snapshot first; only then may
retained outputs be published. The publication changes routing and makes subsequent
snapshot_applicable false. Native flips/count and edge rewrites trigger epoch_due;
operators run `epoch` (or orchestrate this check) rather than incorrectly relabeling
an evolving snapshot as covered. The mean of bounds is a workload statistic.

## Workers and cloud

LocalQueue persists visibility leases, receipts and completion in RocksDB.
SQSQueue calls the actual AWS SDK. Both are at-least-once. LocalWorker and CloudWorker
use the same claim/fence/native publication semantics. Direct gRPC uses the documented
JSON unary wire schema `/chrysalis.Worker/{Encode,Claim,Acquire,Publish,Work,Query}`. Acquire
binds a logical queued claim to one physical worker. Encode aggregates
requests over a 3ms window with a maximum of 32 raw items and uses actual PyTorch
inference. Production cloud RPC requires caller-supplied mTLS materials; insecure
loopback is explicit development configuration. Background messages contain claims,
the successor revision, immutable S3 locators and raw checksums. S3 snapshots commit
their checksum manifest last and restore only after each object checksum verifies.

The release audit extended Acquire to return a retained native vector, so remote
SQS workers reuse calibration outputs without another encoder call. Direct Encode
responses include measured batch wall time apportioned across aggregated items;
the cloud host accounts its query/boundary share. A retried completion event also
finishes any interrupted reservation reconciliation. Remote synchronous CLIP
resolution transports checksum-verified image bytes instead of host-local paths.
These protocol paths have loopback integration tests; live AWS remains untested.

The corpus remains read-only. Raw JSONL is version-tagged; image manifests must
retain immutable image bytes alongside their paths. Affine rotation is one-way
after reclamation; rollback needs predecessor re-embedding or independently stored
old segments, which must be added to storage accounting. Chaining is rejected;
there is no implicit composition of bridges.

## Scheduling and money

Heat counts actual scored candidates; centrality is maintained directed in-degree
over layers. Utility is exactly heat * epsilon_r * in-degree, with zero utility
when either multiplicative discrete factor is zero. Zero-heat items still migrate
in deterministic region/ID order, ensuring convergence. A durable dollar bucket
reserves predicted batch work, then reconciles measured work (including retry
records sharing the job). Price inputs are explicit; category-specific dictionaries
can distinguish spot background, on-demand resolution, query/calibration and burst
prices. Work logs record every inference batch, including queries, calibration,
offline validation, independent oracle generation and baseline re-embedding.

Only scheduled jobs are admission-controlled by the bucket. Query encoding,
calibration and boundary resolution are accounted but not blocked by its admission
rule; separate budgets are needed to control them. Unexpected batch overruns create
debt and block further admission, so reservation is not a hard invoice ceiling.
Idle worker allocation, storage, network and AWS request charges require separate
operator billing inputs. GPU busy here means timed encoder batch wall time while
on CUDA (zero on CPU), not independently measured kernel occupancy; this is a
metric limitation relative to a fully instrumented A10G study. Durable reservation
metadata acts as an outbox: Scheduler.recover_pending reconstructs claims and
delivery after reserve/claim/send interruption. Duplicate delivery is fenced.
If a remote worker dies after physical inference and before reporting telemetry,
its unreported cost remains unknown; the ledger cannot recover a nonexistent
measurement. Pause/resume is durable; convergence restarts after recovery.

## Auditor

Each native publication durably queues its pivot. `audit`/cloud-host/migrate --repair
drains this queue; the benchmark can defer repair for the no-repair ablation. A pivot
pool includes outgoing/reverse adjacency and two-hop outgoing/reverse neighbors on
each layer. Pruning uses gamma sums with zero for native endpoints; uncertain
inequalities are persisted for later inspection/repair. It does not encode pool
items, does not introduce full-corpus neighbors, and is a heuristic. Adjacency and
reverse sets change together under the C++ exclusive lock; repaired topology syncs
before the service lock releases.

## Storage accounting and recovery limits

Store.measure sums all live files below one serving root: vector segments and
temporary overlays, raw JSONL, maps/residuals/epochs/queues/manifests/WAL/SST files,
and transient files not yet reclaimed. It records the maximum after writes and
operation boundaries. The evaluator keeps oracle vectors, source model weights,
input datasets and experiment checkpoints outside serving roots; those are
reported as excluded evaluation/shared-input storage. RAM mirrors are additional
memory, not persistent bytes. This file sampler is not a filesystem allocation
profiler: RocksDB compaction can transiently exceed a between-operation sample.
External continuous monitoring is required for a strict peak-storage claim.

Hard-exit tests exercise process crashes at data sync, manifest sync and reclamation
with RocksDB WAL recovery. Startup discards unreferenced vector writes and expires
claims; unexpired claims remain protected. On Windows, fsync flushes files but
directory rename/power-loss semantics are not independently established. Linux
directory fsync is supported. No power-cut, multi-host failover, or real AWS
preemption experiment is claimed without execution evidence.

Retirement compacts native segments, removes maps and calibration residual/scoring
machinery, and routes subsequent searches through a pure native graph path. That
path performs no interval certification, resolution queueing or durable heat
updates; it reports bound=null. Historical work/lease ledgers remain inspectable.
The later native fast-path optimization has separate executed-source evidence.

The measured time to mean bound 0.95 uses a configured sliding served-query window
(20 for smoke), calibrated-upgrade elapsed plus the individual replica's elapsed
time. This is an explicit reconstruction metric; the historical window is unknown.
Observed sequential QPS includes query encoding and intervening local queue drains.
Reciprocal mean index latency is separately labeled a service rate. Neither is a
saturated concurrent reproduction of the paper's serving workload.
