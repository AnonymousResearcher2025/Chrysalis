# Artifact availability and execution

This release provides the Chrysalis algorithm and operational workflow in C++17
and Python: graph construction, regional calibration, streaming migration,
interval search, embedding workers, persistence/recovery, scheduling, repair,
baselines and evaluation commands. The repository includes executable tests and
recorded real-input validation evidence. Model checkpoints and large datasets
are fetched separately or supplied through versioned manifests.

Repository: https://github.com/AnonymousResearcher2025/Chrysalis.
License: MIT, using the existing repository copyright notice.

The paper's measurements were produced by the authors' earlier implementation,
which became inaccessible after a laptop failure. This release reconstructs the
implementation from the paper. Its unit/protocol tests and small real-encoder
validation were executed separately; they are recorded with their own source and
input hashes. No historical logs or original settings have been invented. The
authors have chosen not to rerun the paper's benchmark campaign for this release.

The runtime defaults specified in the paper are provided. Settings the paper does
not specify are documented implementation choices in configs/provisional.json
and docs/ARCHITECTURE.md. Immutable dataset manifests, prices and local paths are
run inputs. A deployment cannot recover those values by inspecting a table of
results; operators must supply them explicitly.

## Reviewer entry points

1. Follow README.md to install dependencies and build the actual native extension.
2. Run the tests and inspect docs/RELEASE_READINESS.md for executed release checks.
3. Regenerate the shipped measured tables with
   `python -m chrysalis.cli tables evidence/smoke` (no model download).
4. Prepare the immutable public smoke input with
   `python scripts/smoke_data.py data/smoke`; run the optional real-encoder workflow
   from README.md if independent execution is desired.
5. Use explicit dataset manifests and configs/provisional.json for larger inputs;
   use docs/TRACEABILITY.md to inspect paper-to-code requirements and ambiguities.

## Suggested paper statement

Short availability sentence:

"The Chrysalis source code, execution instructions, tests, and validation evidence
are available at https://github.com/AnonymousResearcher2025/Chrysalis."

Implementation-provenance note for the repository or artifact appendix:

Code, build instructions, tests, and recorded validation evidence for Chrysalis
are available in the linked repository. The release is a reconstruction of the
implementation used for the paper after the original prototype became
inaccessible. It implements the paper's migration workflow and documents settings
not specified in the paper; the paper's original benchmark campaign has not been
repeated for this release.

Tag a fixed release after publication and use its commit/tag URL in the paper so
the artifact link stays stable. The repository URL above is the canonical project
link; a release tag records the exact version reviewed.
