# Reconstruction specification

Source: supplied seven-page Chrysalis.pdf, SHA256
`f31e8fd2b976e7756212694c8becb4f1e862eacd2fea640ba4dc9ed2cedd974c`.
The workspace copy and Downloads/Chrysalis (11).pdf are identical. All pages,
including references, were read; Figure 1 and Algorithm 1 were visually inspected.
This is a new reconstruction. No original source, logs, configurations, model
revisions, or historical execution evidence were provided.
The source PDF is retained privately; the public copy records its checksum.

## Specified

* Single read-only corpus, states legacy/bridged/resolving/native; successor-only
  queries, old-space coarse partition, R=256, 200 fit + 200 residual pairs/region.
* Equal dimensions: orthogonal Procrustes. Unequal dimensions: rank-64 affine.
* Euclidean distance; native corpus/query vectors normalized, bridge outputs not.
* Regional distance errors epsilon_r, vector residuals gamma_r, and query maximum
  errors epsilon_cert are three different arrays/radii. Quantiles use
  ceil((1-alpha)(m+1)); unsupported order statistics are infinite.
* Frozen graph/manifest calibration; exact candidate embeddings retained until all
  replay scoring completes, then published. Publication already invalidates the
  proposition's snapshot scope. Recalibration does not cure subsequent changes.
* Algorithm 1: midpoint beam traversal; ambiguity against kth interval; rho=4;
  async default; resolving retains published vector; certificate m/k with strict
  endpoint comparison. Examined-set recall is distinct from full-corpus recall.
* Graph M=32, efConstruction=200, alpha_prune=1.2; Table 5 efSearch=96, k=10.
* Utility heat * epsilon_r * in-degree, region batches, dollar token bucket.
* Heuristic local auditor using gamma, reverse and two-hop edges; no forced pool
  embeddings; native-only repair invokes no encoder.
* Data sync -> manifest sync -> reclamation. RocksDB WAL, S3 snapshots/raw data,
  SQS background and gRPC synchronous small batches, PyTorch FP16 GPU workers.
* AWS testbed and Tables 2-5 are historical comparison targets, never fixtures.
  Five seeded Zipf(1.0) replays. Paper-scale results have not been reproduced.

## Consequential gaps (clarification requested)

The PDF literally says "definition of dbar_r", "size pairs", "m_q=value",
"query pool", "threshold", and "whole corpus or non-seed corpus". Table 1
contains source/split placeholders; rare entities are similarly unspecified.
Model checkpoint revisions, preprocessing, replay length, load generation,
affine objective/regularization, ambiguity overlap measure, and layer/concurrency
construction are not recoverable from this document.

Implement interfaces that accept these choices explicitly. Provisional configuration
is not evidence of the original settings. Historical reproduction remains blocked
until dataset releases and selection manifests are supplied. Dataset annotation
inputs must identify entities and their counting scope; do not invent an NER method.

## Mathematical limits

Proposition 1 is marginal query-item coverage with regional exchangeability;
regional calibration is not a joint graph-edge guarantee. Proposition 2 is marginal
query maximum coverage on the exact frozen routing snapshot under exchangeability.
The evolving index's bound is an empirical signal carrying an explicit
snapshot-applicability flag, not a full-corpus ANN guarantee. Repeated query
identities in Zipf replay do not themselves establish exchangeability.
Empty competitor sets use vacuous comparison; fewer than k returned items divide
by requested k (and are flagged). Exact ranks break ties by ID; strict certificate
comparison deliberately excludes distance ties. Nonfinite estimates are rejected;
infinite radii propagate conservatively. No exactly-once encoder execution claim
is made: crashes/lease expiry can repeat inference. Chaining is rejected.
