# Reconstruction provenance

This repository was newly authored from the supplied paper. It does not contain
the lost prototype, reconstructed historical commits, original experiment logs,
AWS deployment evidence, or recovered historical configurations. The historical
Table 2-5 values do not appear as expected outputs anywhere in the test suite.

The authors state that the experiments reported in the paper were previously
executed with the original prototype. The repository's build/tests and real-input
validation are evidence for this reconstruction. The original benchmark campaign
is not being rerun for publication of this code, and these two evidence histories
must not be conflated.

Model revisions were resolved from public Hugging Face repositories and recorded
in configs/models.lock.json. They are the reconstruction's checkpoint choices,
not evidence of which revisions generated the paper. Configuration files identify
all provisional choices. Source PDF checksum appears in SPECIFICATION.md.

Tests with synthetic vectors establish implementation properties. Real-input CPU
smoke runs use the explicitly hashed AG News selection and actual pinned MiniLM
and MPNet inference. AG News is outside Table 1; smoke results are not a reproduction
of the Wiki/NQ, MARCO, or LAION historical experiments. Testbed differences, small
samples, different beam/layer parameters, and independent dataset selection must
remain visible in every result description.

On this host, Box returned Windows cloud-filesystem errors for directory probes
and compiler headers. Build/validation work therefore moved to local scratch.
Successful outputs and executed environment records are retained. A premature
smoke attempt (smoke-001) used the old extension and failed at the incremental
DualIndex interface; it is not counted as a successful run. No results from failed
runs are presented as completed experiments.
