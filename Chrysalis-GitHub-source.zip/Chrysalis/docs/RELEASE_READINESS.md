# GitHub artifact release readiness

The code is prepared for publication as the current Chrysalis research
implementation. Publication does not require rerunning the authors' original
benchmark campaign. It does require that the release describe its implementation
choices and executed checks accurately. The paper's earlier results remain the
paper's results; the code release has its own build/test/validation evidence.

## Executed release checks

| Check | Executed evidence |
|---|---|
| Core, recovery, concurrency and protocol tests | 33 passed; zero failures/skips; docs/release-tests.xml |
| Exact GitHub source tree | newly compiled native extension; 33 passed again in 29.52s; docs/github-source-tests.xml |
| Offline evidence regeneration | Tables 2-5 regenerated from shipped raw records in the lean GitHub tree |
| Native package build | Windows CPython 3.12 wheel built with C++17/Zig |
| Installed package outside checkout | docs/installed-wheel-check.json; installed C++ kernel searched a real graph |
| Installed default resources | model lock, smoke and paper-default configuration files loaded outside checkout |
| Immutable dataset preparation | pinned AG News Parquet SHA fc508d6d9868594e3da960a8cfeb63ab5a4746598b93428c224397080c1f52ee |
| Input equality | newly prepared corpus/query hashes exactly match the recorded smoke input |
| Current real PyTorch/gRPC operation | two raw AG News texts encoded with pinned MPNet over aggregated loopback gRPC; normalized 2x768 output |
| Main validation source integrity | all 37 recorded execution snapshots match their stored SHA256 |
| Historical reconstruction smoke | genuine five-seed complete migration and raw query records; documented in FINAL_REPORT.md |

The wheel was installed into a separate virtual environment and loaded outside
the repository. Dependency packages were shared with the recorded environment;
this was not a fresh internet dependency-resolution test. Hosted Linux/Windows
CI is configured to build, test and check wheel installation, but has not been
executed on GitHub in this environment. The existing smoke benchmark was not
rerun during this publication audit. The two-item encoder check is an operation
test rather than a benchmark or new paper result.

## Issues corrected during publication audit

* GitHub source packaging now retains real evidence under evidence/smoke instead
  of losing it to the ignored runs/data directories. Raw query IDs, timings,
  intervals, coverage, measured economics and exact executed-source snapshots are
  preserved. Large model weights, raw datasets and build caches are excluded.
* Wheel/sdist packaging includes configuration resources and required dependency
  metadata. The installed CLI resolves defaults outside the source checkout.
  Portable Windows wheel building uses Zig when available.
* Dataset preparation fetches an immutable release instead of current server rows
  and a separately queried revision. It hashes the downloaded Parquet and verifies
  existing prepared inputs. Dataset-tool dependencies have their own pinned file.
* Remote SQS workers reuse retained calibration vectors, check successor versions
  before inference, and publish through the same fenced host protocol.
* The host accounts measured direct gRPC query/boundary work. Encoder batch wall
  time is apportioned across aggregated requests; the metric does not claim GPU
  kernel occupancy. Duplicate completion delivery finishes interrupted monetary
  reconciliation. Invalid/nonfinite monetary inputs and silently changed restart
  prices are rejected.
* Synchronous remote CLIP transport passes checksum-verified image bytes, so it
  does not rely on the encoder sharing the host's local image paths. Transport is
  tested; actual P3 model execution remains unrun.

## Paper settings and scope

M=32, efConstruction=200, alpha_prune=1.2, efSearch=96, R=256, 200 fitting and
200 residual pairs per region, rank at most 64 and rho=4 are provided as paper
defaults. The defaults do not invent historical corpus releases, entity extraction,
checkpoint revisions, replay support or cloud prices. Those unknown historical
details are separate from mathematically correct, executable reconstruction choices.
All such choices are exposed in configuration/architecture documentation.

Certificates cover the examined set on a frozen calibration snapshot under the
paper's exchangeability assumptions. Evolving-index measurements are labeled;
no statement here upgrades that scope to global ANN recall. Cloud APIs are genuine
SDK/gRPC implementations, but live AWS tests, paper-scale throughput and GPU
measurements are not asserted to have passed. Reviewers can execute supplied
commands with their own raw-input manifests and infrastructure.

## Publication metadata

CITATION.cff uses anonymous contributors for this public review copy.
The authors selected MIT; LICENSE preserves the repository's existing 2026
AnonymousResearcher2025 notice. The canonical repository is
https://github.com/AnonymousResearcher2025/Chrysalis. No DOI, historical release
date, commit history or CI badge has been invented. Publish a fixed tag and use
its stable URL in the artifact statement. Suggested text is in ARTIFACT.md.
The companion full archive carries small serving databases; the lean GitHub
source archive carries code, documentation and measured evidence. This public copy has been anonymized as described in ANONYMIZATION.md;
private originals remain the authoritative evidence.
