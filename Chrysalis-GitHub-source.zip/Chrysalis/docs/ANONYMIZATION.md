# Anonymous public release

This copy omits the author-bearing source PDF and uses anonymous citation metadata. Hostnames, personal paths, names and emails in validation metadata are explicitly redacted. Private original evidence is preserved separately. Public redacted files are not claimed to be byte-identical to private logs. Measured numeric values, timestamps, query IDs, scientific configurations and algorithm code are unchanged. RELEASE-SHA256.txt hashes this public copy.
