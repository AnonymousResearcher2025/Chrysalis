"""Artifact tests."""
