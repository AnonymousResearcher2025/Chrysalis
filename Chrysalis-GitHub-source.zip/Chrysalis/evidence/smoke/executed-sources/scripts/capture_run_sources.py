"""Retain exact hash-verified source used by the measured smoke-003 run.

Only the known post-run legacy claim change is reversed when capturing that file.
This is not an attempt to recover historical prototype source. Every copied byte
must match the SHA recorded at this reconstruction run's actual start.
"""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
run = root / 'runs/smoke-003'
expected = json.loads((run / 'source-hashes.json').read_text())
dest = run / 'executed-sources'
for name, digest in expected.items():
    path = root / Path(name)
    value = path.read_bytes()
    # Later metric/CLI additions may differ; this helper must never label them
    # as executed unless their original snapshot is actually available.
    if hashlib.sha256(value).hexdigest() != digest:
        print('source changed after execution:', name)
        continue
    target = dest / Path(name)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(value)
