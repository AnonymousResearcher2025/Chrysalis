"""Download a small real public corpus. AG News is a smoke input, not Table 1."""
import json
from pathlib import Path
import sys
import requests
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from huggingface_hub import HfApi
from chrysalis.datasets import prepare

dest = Path(sys.argv[1] if len(sys.argv) > 1 else 'data/smoke')
cache = dest.parent / 'agnews-source'
cache.mkdir(parents=True, exist_ok=True)
rows = []
for offset in range(0, 300, 100):
    r = requests.get('https://datasets-server.huggingface.co/rows', params={
        'dataset': 'fancyzhx/ag_news', 'config': 'default', 'split': 'train', 'offset': offset, 'length': 100}, timeout=60)
    r.raise_for_status()
    (cache / f'page-{offset}.json').write_text(r.text, encoding='utf-8')
    rows.extend(dict(id=f'train:{v["row_idx"]}', raw=v['row']['text']) for v in r.json()['rows'])
corpus, queries = cache / 'corpus.jsonl', cache / 'queries.jsonl'
corpus.write_text(''.join(json.dumps(x) + '\n' for x in rows[:160]), encoding='utf-8')
queries.write_text(''.join(json.dumps(x) + '\n' for x in rows[160:]), encoding='utf-8')
revision = HfApi().dataset_info('fancyzhx/ag_news').sha
print(prepare(corpus, queries, dest, dataset_id='fancyzhx/ag_news', release=revision,
              selection='First 160 train rows corpus; next 140 train texts query pools; AG News reconstruction smoke only',
              seed=42, counts=dict(residual=20, replay=20, offline=20, evaluation=32)))
