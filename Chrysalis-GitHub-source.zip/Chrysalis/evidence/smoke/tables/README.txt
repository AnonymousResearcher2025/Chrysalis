New measured outputs. Index latency excludes query encoding; end-to-end latency includes it.
qps_observed divides query count by measured sequential replay elapsed time, including query encoding and intervening local queue drains.
index_service_rate_per_second is reciprocal mean index latency, not observed throughput.
This single-client smoke is not a saturated single-core QPS reproduction.
