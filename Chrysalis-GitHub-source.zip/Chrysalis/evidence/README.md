# Recorded validation evidence

smoke contains genuine measured query records, input/configuration hashes, durable ledger exports, and their executed source snapshots. These are the reconstruction CPU smoke results, not the historical paper measurements. Large raw corpora, model weights and serving databases are outside the GitHub tree; the full companion archive includes the smoke serving databases.

Run `python -m chrysalis.cli tables evidence/smoke` to regenerate tables. See docs/ARTIFACT.md for the original-experiment/code-release relationship.
